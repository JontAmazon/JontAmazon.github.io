public class test_stuff {
    public static void main(String[] argz) {
        Integer nbr = 0;
        for (int i = 0; i < 4; i++) {
            increment(nbr);
        }
        System.out.println(nbr);
    }

    public static void increment(Integer x) {
        x += 1;
    }

    //
    //
    //     OH MY GOD, DETTA FUNKAR INTE ENS I JAVA......    OMG   !!!!!
    //
    //
    //

}
