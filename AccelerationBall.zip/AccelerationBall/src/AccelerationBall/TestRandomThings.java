/*
*/
package AccelerationBall;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.net.URL;


public class TestRandomThings {
    public TestRandomThings() {
        loadAudio();
    }

    public void loadAudio() {
        try {
            URL url = this.getClass().getClassLoader().getResource("resources/_game_bra2_5min(wav).wav");
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(url);
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        }
        catch(Exception ex)
        {  }

        for (int i=0; i<10; i++) {
            try {
                Thread.sleep(1000);
            }
            catch (Exception e) {  }
        }
    }

    public static void main(String[] argumentums) {
        TestRandomThings jonte = new TestRandomThings();
    }


}
//

