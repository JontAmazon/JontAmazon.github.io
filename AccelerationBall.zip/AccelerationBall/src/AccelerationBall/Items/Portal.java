package AccelerationBall.Items;

import javax.swing.*;

public class Portal extends Item {
    //Implement another world, another game. Then use this item to get there.




    public Portal(ImageIcon imageIcon) {
        super(new ImageIcon("src/resources/apple.png"));
        lifeTime = 10000000;
        //ÄNDRA BILD
    }

}
