package AccelerationBall.Items;

import javax.swing.*;

public class Apple extends Item {

    public Apple() {
        super(new ImageIcon("src/resources/redApple_small2.png"));
    }















}

