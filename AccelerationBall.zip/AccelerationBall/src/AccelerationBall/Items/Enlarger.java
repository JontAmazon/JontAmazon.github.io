package AccelerationBall.Items;

import javax.swing.*;

public class Enlarger extends Item {

    public Enlarger() {
        super(new ImageIcon("src/resources/plus1_small.png"));
        lifeTime = 1000*10;
    }
}
