package AccelerationBall.Items;

import javax.swing.*;

public class InvisibilityCloak extends Item {

    public InvisibilityCloak() {
        super(new ImageIcon("src/resources/ryuk_42x44.png"));
        lifeTime = 1000*10;
    }
}
