package AccelerationBall;

public class Menu {
    // TODOS =
    //       = *Menu background*
    //       = Title:  "ACCELERATION BALL (TM)"
    //       = Button: "Play Introduction"  (endast devil)
    //       = Button: "Play Game"       (enter leder hit)
    //       = Visar förra omgångens (Time + Apples) --- bredvid "Play Game" nog.
    //


    public Menu() {




    }











}






