package AccelerationBall;

import AccelerationBall.Items.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.*;
import java.util.List;
import java.util.Timer;
import javax.swing.*;

public class Board extends JPanel {
    private static boolean inGame;
    private SmileyBall smiley;
    private GhostBall ghost;
    private DevilBall devil;
    private int frenzyCounter = 0;
    private long frenzyTimeCounter = 0;

    //Changeable parameters:
    private boolean easyMode;
    private boolean mediumMode;
    private boolean hardMode;
    private long appleLife;
    private long fireLifeTime;
    private int fireParameter;
    private int immortalityParameter;
    private void setAppleLife(long life) { appleLife = life; }
    private void setFireLifeTime(long life) { fireLifeTime = life; }
    private void setFireParameter(int nbr) { fireParameter = nbr; }
    private void setImmortalityParameter(int nbr) { immortalityParameter = nbr; }

    private Timer timer;
    private long birthTime = System.currentTimeMillis();
    private long time = birthTime;
    private String finalTime;

    //Items:
    private ArrayList<Item> items = new ArrayList<>();
    private Apple apple = new Apple();
    private Integer appleCounter = 0;
    private Random rand = new Random();
    private int random = -1;

    //Audio related:
    private boolean isPlayingGameMusic;
    private boolean isPlayingSuperMario = false;

    //Images:
    ImageIcon ii = new ImageIcon("src/resources/background2.png");
    ImageIcon ii2 = new ImageIcon("src/resources/white_small.png");
    ImageIcon ii3 = new ImageIcon("src/resources/devil1_41x41.png");
    private Image backgroundImage = ii.getImage();
    private Image whiteImage = ii2.getImage();
    private Image menuImage = ii3.getImage();

    //Background related:
    private JButton easyButton = new JButton("EASY");
    private JButton mediumButton = new JButton("MEDIUM");
    private JButton hardButton = new JButton("HARD");
    private JButton muteButton = new JButton("Un-mute");
    private JLabel header;
    private JLabel appleResult;
    private JLabel timeResult;
    private JLabel pressEnterToPlay;
    private static boolean isMuted = true;


    ////////////////////////////////////////////////////////
    //////////////// TO-DO LIST ////////////////////////////
    ////////////////////////////////////////////////////////
    // TODO = EV = helskärm
    // TODO = fler items
        //blixt-stun-item. 5 charges.
    // TODO = ersätt wav-filer med mp3
    // TODO = Frenzy:
        //efter 1-3 äpplen
        //försvinner efter 3 äpplen
        //äpplet blir gult 1.7 sec innan
    // TODO = odödlig blir opaque när 1.5 sec kvar
    // TODO = ändra titeln. större också. annan färg?

    // TODO = Hemsida, med highscore (endast 1 per ip?)
    // TODO = Highscore - skriva till en fil
        //bara 1 per person.
    // TODO = fixa Exception och att det ibland går ubersnabbt.
        //det går ubersnabbt vid Enter UNDER spelgången. Har att göra med att man kör startGame()...
        // utan att göra gameOver() förmodligen. Då skapas en ny timer, som också kör run() var 16e ms.
    // TODO = high score list. Flera kategorier: 10 äpplen så snabbt som möjligt. 20, 30, 40, 50, 70, 100.
    // TODO = en JLabel utan bakgrund som med stora " << " visar vilken nivå som just nu är vald.
    //        Flytta "press ENTER to play" till under Easy/Medium/Hard, och gör den texten större.

    // TODO = anställ Frej för sommarjobb: låt djävulen studsa på planeterna.
    // TODO = låt djävulen studsa på en romb i mitten.


    // Methods for initializing:
    public Board() {
        addKeyListener(new TAdapter());
        setFocusable(true);
        loadButtons(this);
        loadLabels();

        startGame();
        gameOver();

        setHard();
    }
    private void loadButtons(JPanel jpanel) {
        muteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isMuted = (! isMuted);
                if (isMuted) {
                    Game.stopBackgroundMusic();
                    muteButton.setText("   Un-mute   ");
                }
                if (! isMuted) {
                    Game.playBackgroundMusic();
                    muteButton.setText("Mute music");
                }
                jpanel.requestFocusInWindow();
            }
        });
        muteButton.setBackground(Color.BLUE);
        muteButton.setForeground(Color.RED);
        this.add(muteButton);

        easyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
                setEasy();
            }
        });
        easyButton.setBackground(Color.GREEN);
        easyButton.setForeground(Color.BLACK);
        easyButton.setFont(new Font("Verdana", 1, 18));
        this.add(easyButton);

        mediumButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
                setMedium();
            }
        });
        mediumButton.setBackground(Color.BLUE);
        mediumButton.setForeground(Color.BLACK);
        mediumButton.setFont(new Font("Verdana", 1, 17));
        this.add(mediumButton);

        hardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startGame();
                setHard();
            }
        });
        hardButton.setBackground(Color.RED);
        hardButton.setForeground(Color.BLACK);
        hardButton.setFont(new Font("Verdana", 1, 18));
        this.add(hardButton);
    }

    private void setEasy() {
        easyMode = true;

        smiley.setSpeed(3);

        ghost.setStartingSpeedLimit(0.50);
        ghost.setSpeedLimit(0.50);
        ghost.setMaxSpeedLimit(1.00);

        devil.setNormalAcceleration(0.07);
        devil.setFrenzyAcceleration(0.07*1.3);
        devil.setAcceleration(0.07);
        devil.setFriction(0.99);

        this.setFireLifeTime(10*1000);
        this.setFireParameter(250);

        setCommonParameters();
    }
    private void setMedium() {
        mediumMode = true;

        smiley.setSpeed(3.30);

        ghost.setStartingSpeedLimit(0.65);
        ghost.setSpeedLimit(0.65);
        ghost.setMaxSpeedLimit(1.13);

        devil.setNormalAcceleration(0.10);
        devil.setFrenzyAcceleration(0.10*1.3);
        devil.setAcceleration(0.10);
        devil.setFriction(0.9885);

        this.setFireLifeTime(9*1000);
        this.setFireParameter(600);

        setCommonParameters();
    }
    private void setHard() {
        hardMode = true;

        smiley.setSpeed(3.60);

        ghost.setStartingSpeedLimit(0.90);
        ghost.setSpeedLimit(0.90);
        ghost.setMaxSpeedLimit(1.25);

        devil.setNormalAcceleration(0.14);
        devil.setFrenzyAcceleration(0.14*1.2);
        devil.setAcceleration(0.13);
        devil.setFriction(0.985);

        this.setFireLifeTime(7*1000);
        this.setFireParameter(1800);

        setCommonParameters();
    }
    private void setCommonParameters() {
        ghost.setTimeToReachMaxSpeed(60*1000);

        devil.setNormalOrthogonalBounce(1.80);
        devil.setBounce(1.80);
        devil.setFrenzyBounce(1.80);
        devil.setParallelBounce(1.18);

        this.setImmortalityParameter(15);
        this.setAppleLife(7*1000);

        this.requestFocusInWindow();
    }


    private void loadLabels() {
        header = new JLabel("ACCELERATION BALL (TM)");
        header.setFont(new Font("Verdana",1,36));
        header.setForeground(Color.BLUE);
        this.add(header);

        appleResult = new JLabel("Apples: ");
        appleResult.setFont(new Font("Verdana",1,12));
        appleResult.setForeground(Color.red);
        this.add(appleResult);

        timeResult = new JLabel("Time: ");
        timeResult.setFont(new Font("Verdana",1,12));
        timeResult.setForeground(Color.red);
        this.add(timeResult);

        pressEnterToPlay = new JLabel("Press ENTER to Play!");
        pressEnterToPlay.setFont(new Font("Verdana", 1, 11));
        pressEnterToPlay.setForeground(Color.CYAN); //blue
        this.add(pressEnterToPlay);
    }
    public void addNotify() { super.addNotify(); }
    private class TAdapter extends KeyAdapter {
        @Override
        public void keyReleased(KeyEvent e) {
            int key = e.getKeyCode();
            if (key == KeyEvent.VK_ENTER) {
                startGame();
                if (easyMode) {
                    setEasy();
                } else if (mediumMode) {
                    setMedium();
                } else {
                    setHard();
                }
            } else {
                smiley.keyReleased(e);
            }
        }
        @Override
        public void keyPressed(KeyEvent e) {
            smiley.keyPressed(e);
        }
    }
    private class ScheduleTask extends TimerTask {
        @Override
        public void run() {
            if (inGame) {
                time += 10;
                smiley.move();
                ghost.move(smiley);
                devil.move(smiley);
                checkCollision();
                updateBallStatuses();

                generateItems();
                checkItemCollisions();
                updateItems();
            }

            repaint();
        }
    }


    // Methods that run every 16 ms:
    private void checkCollision() {
        if (smiley.intersects(ghost) || smiley.intersects(devil)) {
            gameOver();
        }
        if (smiley.getRect().intersects(apple.getRect())) {
            if (! isMuted) {
                Game.playAppleAudio();
            }
            devil.setImage1();
            appleCounter++;
            frenzyTimeCounter = 0;
            generateNewApple();
        }
    }
    private void updateBallStatuses() {
        //smiley:
        smiley.updateImmortality();
        if (!smiley.isImmortal() && !isPlayingGameMusic) {
            if (! isMuted) {
                Game.playGameMusic();
            }
            isPlayingGameMusic = true;
            isPlayingSuperMario = false;
        }

        //ghost:
        ghost.turnGhosts(smiley);
        ghost.speedUp(time-birthTime);

        //devil:
        if (! devil.isInFrenzy()) {
            frenzyTimeCounter += 10;
        }
        if (frenzyTimeCounter > appleLife) {
            frenzyTimeCounter = 0;
            frenzyCounter++;
            apple = new Apple();
        }
        if (frenzyCounter == 3) {
            frenzyTimeCounter = 0;
            frenzyCounter = 0;
            devil.frenzy(isMuted);
        }
        if (devil.isInFrenzy() && (time - devil.getFrenzyBirthTime()) > devil.getFrenzyTime()) {
            devil.stopFrenzy();
        }


    }
    private void generateItems() {
        random = rand.nextInt(1000000/16);
        //Intervall=100 ==> 1 item var tioende sekund.
        if (random > 1000 && random < 1000+fireParameter) {
            Fire fire = new Fire(fireLifeTime);
            if (!intersectsWithSomeItem(fire) && !fire.getRect().intersects(apple.getRect())) {
                items.add(fire);
            }
        }
        if (random > 2000 && random < 2000+immortalityParameter) {
            for (Item item : items) {
                if (item instanceof Immortality) {
                    break;
                }
            }
            items.add(new Immortality());
        }
    }
    private void generateNewApple() {
            apple = new Apple();
            while (intersectsWithSomeItem(apple)) {
                apple = new Apple();
            }
    }
    private boolean intersectsWithSomeItem(Item newItem) {
        for (Item item : items) {
            if (newItem.getRect().intersects(item.getRect())) {
                return true;
            }
        }
        return false;
    }
    private void checkItemCollisions() {
        for (Item item : items) {
            if (item instanceof Fire) {
                if (! ((Fire) item).isInPreStatus()) {
                    if (smiley.intersects(item)) {
                        gameOver();
                    }
                }
            } else if (item instanceof Immortality) {
                if (smiley.getRect().intersects(item.getRect())) {
                    if (!isMuted) {
                        Game.stopGameMusic();
                        isPlayingGameMusic = false;
                        Game.playSuperMario();
                        isPlayingSuperMario = true;
                    }
                    ((Immortality) item).consume();
                    smiley.setImmortal();
                }
            }
        }
    }
    private void updateItems() {
        //NOTE = includes removing consumed items.

        for (Item item : items) {
            if (item.getAge() > item.getLifeTime()) {
                item.consume();
            }
            if (item instanceof Fire && ((Fire)item).isInPreStatus() &&
                    ((Fire)item).getAge() > ((Fire)item).getPreStatusChangeTime()) {
                ((Fire)item).changeImage();
            }
        }
        Iterator<Item> it = items.iterator();
        while (it.hasNext()) {
            if (it.next().isConsumed()) {
                it.remove();
            }
        }
    }

    private void gameOver() {
        if (! smiley.isImmortal()) {
            inGame = false;
            //playGameButton.setVisible(true);                  ta bort.
            Game.stopGameMusic();
            if (! isMuted) {
                Game.playBackgroundMusic();
                Game.playGameOverAudio();
            }
            finalTime = Game.displayTime(time, birthTime);
            timer.cancel();
        }
    }
    private void startGame() {
        inGame = true;
        this.requestFocusInWindow();
        Game.stopBackgroundMusic();
        if (! isMuted) {
            Game.playGameMusic();
            isPlayingGameMusic = true; //if muted: will be null.
        }

        smiley = new SmileyBall();
        ghost = new GhostBall();
        devil = new DevilBall();
        appleCounter = 0;
        frenzyTimeCounter = 0;
        frenzyCounter = 0;
        items = new ArrayList<>();
        timer = new Timer();
        timer.scheduleAtFixedRate(new ScheduleTask(), 1200, 16);
        birthTime = System.currentTimeMillis();
        time = birthTime;
    }
    public static void playBounceAudio() {
        if (! isMuted) {
            Game.playBounceAudio();
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        drawObjects(g2d);
        Toolkit.getDefaultToolkit().sync();
    }
    private void drawObjects(Graphics2D g2d) {
        setComponentsVisible(inGame);

        //Update positions for labels and buttons.
            //(Idk why this is requiered...)
        header.setLocation(100, 25);
        pressEnterToPlay.setLocation(320, 75);
        muteButton.setLocation(30, Game.HEIGTH - 110);
        muteButton.setSize(110, 40);
        easyButton.setLocation(320, 105);
        easyButton.setSize(130, 40);
        mediumButton.setLocation(320, 150);
        mediumButton.setSize(130, 40);
        hardButton.setLocation(320, 195);
        hardButton.setSize(130, 40);

        //Background:
        g2d.drawImage(backgroundImage, 0, 0,
                Game.WIDTH, Game.HEIGTH, this);

        //Items:
        for (Item item : items) {
            g2d.drawImage(item.getImage(), item.getX(), item.getY(),
                    item.getImageWidth(), item.getImageHeight(), this);
        }
        g2d.drawImage(apple.getImage(), apple.getX(), apple.getY(),
                apple.getImageWidth(), apple.getImageHeight(), this);
        //Balls:
        g2d.drawImage(smiley.getImage(), smiley.getX(), smiley.getY(),
                    smiley.getImageWidth(), smiley.getImageHeight(), this);
        g2d.drawImage(ghost.getImage(), ghost.getX(), ghost.getY(),
                ghost.getImageWidth(), ghost.getImageHeight(), this);
        g2d.drawImage(devil.getImage(), devil.getX(), devil.getY(),
                        devil.getImageWidth(), devil.getImageHeight(), this);

        //Score:
        appleResult.setLocation(Game.WIDTH-120, 35);
        timeResult.setLocation(Game.WIDTH-120, 20);
        appleResult.setText("Apples: " + appleCounter.toString());
        timeResult.setText("Time: " + Game.displayTime(time, birthTime));
    }
    private void setComponentsVisible(boolean inGame) {
        if (inGame) {
            muteButton.setVisible(false);
            easyButton.setVisible(false);
            mediumButton.setVisible(false);
            hardButton.setVisible(false);
            header.setVisible(false);
            pressEnterToPlay.setVisible(false);
        } else {
            muteButton.setVisible(true);
            easyButton.setVisible(true);
            mediumButton.setVisible(true);
            hardButton.setVisible(true);
            header.setVisible(true);
            pressEnterToPlay.setVisible(true);
        }
    }

}










